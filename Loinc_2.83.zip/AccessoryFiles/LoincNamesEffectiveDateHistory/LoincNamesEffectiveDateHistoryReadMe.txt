The LoincNamesEffectiveDateHistory directory contains the following files:

 - LoincNamesEffectiveDateHistory.csv
 - LoincNamesEffectiveDateHistoryReadMe.txt

The comma separated file is designed as a relational table with each line in the file representing a row in the table. The first row contains column headings. All other rows contain data. The details for the table are provided below.

-----------------------------------
LoincNamesEffectiveDateHistory.csv

Overview:

This file covers the name history in effect from 2.68 forward. Rows are included when the name value was in effect during 2.68 or any later version, or when it was replaced in 2.68. Because a name may have been introduced well before this window and remained unchanged, EffectiveStartDate and EffectiveStartVersion reflect the version in which the name value actually first appeared and may predate 2.68. EffectiveEndDate and EffectiveEndVersion are null when the name is still current in the latest release.

The following name types are tracked:
 - LONG_COMMON_NAME - the LOINC Long Common Name
 - SHORTNAME - the LOINC Short Name
 - DisplayName - the LOINC Display Name
 - CONSUMER_NAME - the LOINC Consumer Name
 - FullySpecifiedName - a concatenation of the six LOINC Parts (Component:Property:Time_Aspct:System:Scale_Typ:Method_Typ)

Columns:
 - LoincNumber - the LOINC term identifier, which is a unique numeric identifier with a check digit
 - NameType - the type of name represented in the row (see list above)
 - NameValue - the name string value that was effective for the given LOINC term and name type during the indicated version range
 - EffectiveStartDate - the release date of the LOINC version in which this name value first appeared for the given LOINC term and name type
 - EffectiveEndDate - the release date of the LOINC version in which this name value was replaced or removed. A null value indicates the name is still current in the latest release.
 - EffectiveStartVersion - the LOINC version identifier in which this name value first appeared
 - EffectiveEndVersion - the LOINC version identifier in which this name value was replaced or removed. A null value indicates the name is still current in the latest release.

Sort order:
This file is sorted by LoincNumber, then by NameType, then by EffectiveStartDate.